<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<h3>Welcome {{ user_name }}</h3>
<?php
	echo $submenu_screen;