<form action="<?php echo site_url('main/hauth/login/OpenID'); ?>" method="POST">
	<label>Open ID URL:</label>
	<input type="text" name="open_id_identifier" />
	<input type="submit" name="login" value="Login" />	
</form>
<p>Visit <a href="http://openid.net/get-an-openid/" target="_blank">http://openid.net/get-an-openid/</a> for more information about OpenID</p>
