DROP TABLE IF EXISTS `his_pangkat`; 
/*split*/
DROP TABLE IF EXISTS `mas_pangkat`; 
/*split*/
DROP TABLE IF EXISTS `mas_status_pegawai`; 
/*split*/
DROP TABLE IF EXISTS `pegawai`; 