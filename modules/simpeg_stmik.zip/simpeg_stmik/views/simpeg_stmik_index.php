<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<h4>simpeg_stmik</h4>
<?php echo $content; ?>
