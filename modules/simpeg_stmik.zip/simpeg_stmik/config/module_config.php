<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['module_table_prefix']  = 'sp';
$config['module_prefix']        = 'simpeg_stmik';